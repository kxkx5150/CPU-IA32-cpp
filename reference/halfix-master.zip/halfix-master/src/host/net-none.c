#include "util.h"

int net_init(char* netarg)
{
    UNUSED(netarg);
    return -1;
}
int net_send(void* req, int reqlen)
{
    UNUSED(req);
    UNUSED(reqlen);
    return -1;
}
void net_poll(void)
{
}