#ifndef SOFTFLOAT_CONSTANTS_H
#define SOFTFLOAT_CONSTANTS_H

extern const floatx80 floatx80_default_nan;

#endif